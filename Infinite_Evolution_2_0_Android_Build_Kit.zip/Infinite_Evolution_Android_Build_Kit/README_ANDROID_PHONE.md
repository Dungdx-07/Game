# Infinite Evolution 2.0 — tạo APK bằng điện thoại Android

## Tình trạng chính xác

- Gói `Infinite_Evolution_2_0_Polished_Project.zip` là **mã nguồn Godot**, không phải APK.
- `build-android.yml` là quy trình GitHub Actions để tải Godot 4.7.2, export templates và Android SDK trên máy build đám mây rồi tạo APK ARM64.
- APK chỉ tồn tại sau khi GitHub Actions chạy thành công. Gói này **không giả vờ chứa APK đã build hoặc đã chạy thử trên điện thoại**.
- Đây là APK debug để cài và thử riêng; chưa phải bản phát hành Google Play. Bản dựng này chưa được runtime-tested trên thiết bị thật.

## Cần chuẩn bị

- Tài khoản GitHub và kết nối Internet.
- Hai tệp trong gói này: `Infinite_Evolution_2_0_Polished_Project.zip` và `build-android.yml`.
- Không cần cài Godot Editor APK trên điện thoại.

## Các bước trên Chrome Android

1. Mở `https://github.com/new`, tạo repository. Chọn **Private** nếu bạn chưa muốn công khai mã nguồn. Tạo repository trống (không thêm README/license tại bước tạo để giao diện đơn giản hơn).
2. Trong repository, chọn **Add file → Upload files**. Tải lên `Infinite_Evolution_2_0_Polished_Project.zip` đúng ở thư mục gốc, rồi commit.
3. Chọn **Add file → Create new file**. Trong ô tên tệp nhập chính xác:

   `.github/workflows/build-android.yml`

4. Mở tệp `build-android.yml` đã tải về bằng trình xem văn bản trên điện thoại, sao chép toàn bộ nội dung và dán vào trình soạn thảo GitHub. Commit tệp.
5. Mở tab **Actions** của repository. Chọn workflow **Build Infinite Evolution 2.0 Android APK**. Nếu workflow chưa tự chạy, chọn **Run workflow**.
6. Chờ đến khi run có trạng thái thành công (dấu tích xanh). Mở run đó, vào **Artifacts**, tải `Infinite-Evolution-2.0-Android-ARM64-APK.zip`.
7. Giải nén artifact. Bên trong phải có `Infinite_Evolution_2_0-debug.apk` và `SHA256SUMS.txt`. Mở APK để cài. Android có thể hỏi bạn cho phép cài ứng dụng từ trình duyệt hoặc trình quản lý tệp.

## Nếu build thất bại

Mở workflow run màu đỏ, mở bước đầu tiên bị lỗi, sao chép phần log lỗi đó và gửi lại. Không cần tải lại Godot Editor. Nếu lỗi xảy ra ở bước download Godot/templates, đó là lỗi tải/build runner; nếu ở bước import/export, log sẽ cho biết lỗi dự án, preset hoặc SDK cụ thể.

## Giới hạn

- Workflow nhắm đến thiết bị Android ARM64, phù hợp với đa số điện thoại Android 13 hiện đại, nhưng kiến trúc CPU của máy vẫn cần tương thích.
- Quy trình này chỉ tạo APK; nó không biến prototype thành game thương mại đã hoàn thiện. Model procedural, AI, hoạt ảnh, cân bằng, hiệu năng 30 FPS và lưu/tải cần được kiểm thử thực tế.
- APK do workflow tạo là debug-signed. Đừng dùng khóa debug này như khóa phát hành và không dùng để phát hành lên Google Play.
